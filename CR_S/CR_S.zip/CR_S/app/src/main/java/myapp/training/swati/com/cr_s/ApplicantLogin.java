package myapp.training.swati.com.cr_s;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ApplicantLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_applicant_login);
    }
}
